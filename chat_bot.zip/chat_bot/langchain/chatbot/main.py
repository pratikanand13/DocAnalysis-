# import streamlit as st
# from langchain_helper import get_qa_chain, create_vector_db

# st.title("Blackbasils chatbot 🌱")
# btn = st.button("Create Knowledgebase")
# if btn:
#     create_vector_db()

# question = st.text_input("Question: ")

# if question:
#     chain = get_qa_chain()
    
#     response = chain(question)

#     st.header("Answer")
#     st.write(response["result"])


import streamlit as st
from langchain_helper import get_qa_chain, create_vector_db

# Set page title and background color
st.set_page_config(page_title="Blackbasils Chatbot 🌱", page_icon=":seedling:", layout="wide")

# Header with custom style
st.markdown(
    """
    <style>
    .header-text {
        font-size: 36px;
        font-weight: bold;
        color: #008080; /* Dark teal color */
        margin-bottom: 30px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown('<p class="header-text">Blackbasils Chatbot 🌱</p>', unsafe_allow_html=True)

# Button to create knowledgebase
if st.button("Create Knowledgebase"):
    create_vector_db()

# Text input for user question
question = st.text_input("Ask your question here:")

if question:
    # Get response from the chatbot
    chain = get_qa_chain()
    response = chain(question)

    # Display the answer
    st.markdown("---")  # Horizontal line for separation
    st.header("Answer:")
    st.write(response["result"])

# Custom footer
st.markdown(
    """
    <style>
    .footer-text {
        font-size: 14px;
        color: #555555; /* Gray color */
        margin-top: 50px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown('<p class="footer-text">Made with ❤️ by Blackbasils</p>', unsafe_allow_html=True)





